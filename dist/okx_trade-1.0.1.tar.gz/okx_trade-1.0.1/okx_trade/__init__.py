from okx_trade.okx_spot import OkxSPOT
from okx_trade.okx_swap import OkxSWAP

__version__ = '1.0.1'
