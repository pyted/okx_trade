ROUND_QUANTITY_ERROR = ['ROUND_QUANTITY_ERROR', ' Trade quantity round error']
ROUND_PRICE_ERROR = ['ROUND_PRICE_ERROR', 'Trade price round error']

QUANTITY_TO_F_ERROR = ['QUANTITY_TO_F_ERROR', 'Trade quantity convert to string error']
PRICE_TO_F_ERROR = ['PRICE_TO_F_ERROR', 'Trade price convert to string error']

TRADE_BUY_TIMEOUT = ['TRADE_BUY_TIMEOUT', 'Not all transactions have been completed after the purchase time']
TRADE_SELL_TIMEOUT = ['TRADE_SELL_TIMEOUT', 'Not all transactions have been completed after the selling time']



