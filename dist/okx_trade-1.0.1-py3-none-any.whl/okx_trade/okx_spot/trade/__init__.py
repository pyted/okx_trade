from okx_trade.okx_spot.trade.open import TradeOpen
from okx_trade.okx_spot.trade.close import TradeClose


class TradeSPOT(TradeOpen, TradeClose):
    pass
