from okx_trade.okx_swap.trade.open import TradeOpen
from okx_trade.okx_swap.trade.close import TradeClose


class TradeSWAP(TradeOpen, TradeClose):
    pass
